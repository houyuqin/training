import React, { Component } from 'react'
import { NavBar ,Icon} from 'antd-mobile';
import {HashRouter as Router,Route,Link} from 'react-router-dom';

export default class Gerenziliao extends Component {
    constructor(){
        super();
        this.state = {
            data:[],
            data1:[]
        }
    }
    componentDidMount(){
        fetch('http://148.70.183.184:8006/stdmine', {
            method: 'GET',
            headers: {
                'Content-Type': 'text/plain; charset=UTF-8'
            },
            })
            .then((res) => res.json())
            .then((res) => {
                this.setState({data:res.data})
                this.setState({data1:this.state.data.splice(this.state.data.length-1)})
                console.log(this.state.data)
                console.log(this.state.data1[0].wusername);
                
            })
    }
    render() {
        return (
            <div style={{width:'100%',height:'100%',backgroundColor:'#fafaf8'}}>
                <NavBar
                style={{backgroundColor:'#708090',color:'white'}}
                icon={<Link to='/'><Icon style={{color:'black'}} type="left" /></Link>}
                >个人资料</NavBar>
               <Router>
                    <div className='stdminebody'>
                        {
                            this.state.data1.map((item)=>(
                                <ul>
                                    <li>
                                        <span>用户名：{item.wusername}</span>
                                    </li>
                                    <li>
                                        <span>性别：{item.wsex}</span>
                                    </li>
                                    <li>
                                        <span>手机号：{item.wphonenumber}</span>
                                    </li>
                                    <li>
                                        <span>年级：{item.wclass}</span>
                                    </li>
                                    <li>
                                        <span>学校：{item.wschool}</span>
                                    </li>
                                </ul>
                            ))
                        }
                         
                    </div>
                </Router> 
            </div>
        )
    }
}
