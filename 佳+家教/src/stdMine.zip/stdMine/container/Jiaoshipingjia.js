import React, { Component } from 'react'
import { NavBar ,Icon} from 'antd-mobile';
import { Link } from 'react-router-dom';
import Item from 'antd-mobile/lib/popover/Item';

export default class Jiaoshipingjia extends Component {
    constructor(){
        super();
        this.state = {
            data:[]
        }
    }
    componentDidMount(){
        fetch('http://148.70.183.184:8005/tasks', {
            method: 'GET',
            headers: {
                'Content-Type': 'text/plain; charset=UTF-8'
            },
            })
            .then((res) => res.json())
            .then((res) => {
                this.setState({data:res.data})
                console.log(this.state.data)
                
            })

        fetch('http://148.70.183.184:8006/stdmine', {
                method: 'GET',
                headers: {
                    'Content-Type': 'text/plain; charset=UTF-8'
                },
                })
                .then((res) => res.json())
                .then((res) => {
                    this.setState({data:res.data})
                    console.log(this.state.data)
                    
                })
    }
    render() {
        return (
            <div style={{backgroundColor:'#fafaf8',height:'100%',}}>
                <NavBar
                style={{backgroundColor:'#708090',color:'white'}}
                icon={<Link to='/'><Icon style={{color:'black'}} type="left" /></Link>}
                >作业评价情况</NavBar>
                <div style={{height:'600px',margin:'15px',padding:'0px 20px',borderStyle:'dotted ' ,overflow:'scroll'}}>
                    {
                        this.state.data.map((item)=>(
                            <div>
                                <p>批改作业人：{item.author}</p>
                                <p>作业评价：{item.pingjia}</p>
                                <p>@{item.wusername}</p>
                                <p>提交了{item.title}的任务作业</p>
                                <p>批改时间：{item.time}</p>
                             
                            </div>
                        ))
                    }
                        
                       
                </div>
            </div>
        )
    }
}
